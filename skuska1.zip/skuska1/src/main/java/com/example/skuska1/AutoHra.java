package com.example.skuska1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

public class AutoHra {
    int N;
    int vyznamne;
    int ciel;
    int[][] plocha;
    void citajLevel (String subor) {

        try {
            BufferedReader br = new BufferedReader(new FileReader(subor));

            N = Integer.parseInt(br.readLine().trim());
            plocha = new int[N][N];

            String[] riadok_2 = br.readLine().trim().split(" ");
            vyznamne = Integer.parseInt(riadok_2[0]);
            ciel = Integer.parseInt(riadok_2[1]);

            String[] pole = new String[N];

            int r = 0;
            String riadok = "";
            while ((riadok = br.readLine()) != null){
                if (!riadok.trim().equals("")) {
                    String[] riad = riadok.trim().split(" ");
                    int c = 0;
                    for (String pr : riad) {
                        plocha[r][c] = Integer.parseInt(pr);
                        c++;
                    }
                    r++;
                }
            }



        } catch (Exception e) {}

    }

    public static void main(String[] args) {

    }
}
