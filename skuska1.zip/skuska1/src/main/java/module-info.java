module com.example.skuska1 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.skuska1 to javafx.fxml;
    exports com.example.skuska1;
}