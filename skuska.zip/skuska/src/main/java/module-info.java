module com.example.skuska {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.skuska to javafx.fxml;
    exports com.example.skuska;
}