package com.example.skuska;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.input.KeyCode;
public class Hra extends Application {

    int[][] plocha;
    int riadky;
    int stlpce;

    Canvas canvas = new Canvas(800, 800);

    Blok vybranyBlok = null;
    int pocetPresunov = 0;

    Color[] farby = {
            Color.RED,
            Color.BLUE,
            Color.GREEN,
            Color.ORANGE,
            Color.CYAN,
            Color.MAGENTA,
            Color.YELLOW,
            Color.PINK,
            Color.BROWN,
            Color.GRAY,
            Color.LIGHTGREEN,
            Color.LIGHTBLUE
    };
    Vychody[] vychody = new Vychody[13];
    Blok[] bloky = new Blok[13];
    @Override
    public void start(Stage primaryStage) throws Exception {
        citajLevel("src/blocks1.txt");

        Pane root = new Pane(canvas);

        canvas.widthProperty().bind(root.widthProperty());
        canvas.heightProperty().bind(root.heightProperty());

        canvas.widthProperty().addListener(e -> kresli());
        canvas.heightProperty().addListener(e -> kresli());

        Scene scene = new Scene(root, 800, 800);

        canvas.setOnMouseClicked(e -> {
            int r = getRow(e.getY());
            int c = getCol(e.getX());

            if (r < 0 || c < 0 || r >= riadky || c >= stlpce)
                return;

            int id = plocha[r][c];

            if (id > 0 && r > 0 && r < riadky - 1 && c > 0 && c < stlpce - 1) {
                vybranyBlok = bloky[id];
            } else {
                vybranyBlok = null;
            }

            kresli();
        });

        scene.setOnKeyPressed(e -> {
            if (vybranyBlok == null)
                return;

            if (e.getCode() == KeyCode.LEFT)
                skusPohyb(vybranyBlok, 0, -1);

            if (e.getCode() == KeyCode.RIGHT)
                skusPohyb(vybranyBlok, 0, 1);

            if (e.getCode() == KeyCode.UP)
                skusPohyb(vybranyBlok, -1, 0);

            if (e.getCode() == KeyCode.DOWN)
                skusPohyb(vybranyBlok, 1, 0);
        });

        primaryStage.setTitle("Blocks");
        primaryStage.setScene(scene);
        primaryStage.show();

        kresli();
    }

    void citajLevel (String subor) {
        try {
            BufferedReader br = new BufferedReader(new FileReader(subor));

            ArrayList<String> lines = new ArrayList<>();

            String line;

            while ((line = br.readLine()) != null) {
                if (!line.trim().equals("")) {
                    lines.add(line);
                }
            }

            br.close();

            riadky = lines.size();

            String[] firstRow = lines.get(0).trim().split("\\s+");
            stlpce = firstRow.length;

            plocha = new int[riadky][stlpce];

            for (int r = 0; r < riadky; r++) {
                String[] riadok = lines.get(r).trim().split("\\s+");

                for (int c = 0; c < stlpce; c++) {
                    plocha[r][c] = Integer.parseInt(riadok[c]);
                    int cislo = Integer.parseInt(riadok[c]);
                    if (cislo > 0 && r > 0 && r < riadky - 1 && c > 0 && c < stlpce - 1) {

                        if (bloky[cislo] == null) {
                            bloky[cislo] = new Blok();
                        }
                        bloky[cislo].id = cislo;
                        bloky[cislo].riadky.add(r);
                        bloky[cislo].stlpce.add(c);

                        if (r >= bloky[cislo].maxRow ) bloky[cislo].maxRow = r;
                        if (r <= bloky[cislo].minRow ) bloky[cislo].minRow = r;
                        if (c >= bloky[cislo].maxCol ) bloky[cislo].maxCol = c;
                        if (c <= bloky[cislo].minCol ) bloky[cislo].minCol = c;
                    }
                }
            }

            int pocetObdlz = 0;
            for (Blok blok : bloky){

                if (blok != null) {
                    boolean jeObdl = true;
                    for (int r = blok.minRow; r <= blok.maxRow; r++){
                        for (int c = blok.minCol; c <= blok.maxCol; c++) {
                            if (plocha[r][c] != blok.id) {
                                jeObdl = false;
                            }
                        }
                    }
                    if (jeObdl){
                        pocetObdlz++;
                    }
                }


            }
            System.out.println(pocetObdlz);



            for (int stl = 0 ; stl < plocha[0].length; stl++){
                if (plocha[0][stl] != -1 ) {

                    int dlzka = -1;
                    if (vychody[plocha[0][stl]] == null) vychody[plocha[0][stl]] = new Vychody();
                    vychody[plocha[0][stl]].id = plocha[0][stl];
                    vychody[plocha[0][stl]].maxRow = 0;
                    vychody[plocha[0][stl]].minRow = 0;
                    vychody[plocha[0][stl]].minCol = stl;
                    int pozicia = stl;
                    while (plocha[0][pozicia++] == plocha[0][stl] ) {
                        dlzka++;
                    }
                    vychody[plocha[0][stl]].maxCol = vychody[plocha[0][stl]].minCol + dlzka;
                    stl +=  dlzka;
                }

            }

            for (int stl = 0 ; stl < plocha[0].length; stl++){
                if (plocha[plocha.length-1][stl] != -1 ) {

                    int dlzka = -1;
                    if (vychody[plocha[plocha.length-1][stl]] == null) vychody[plocha[plocha.length-1][stl]] = new Vychody();
                    vychody[plocha[plocha.length-1][stl]].id = plocha[plocha.length-1][stl];
                    vychody[plocha[plocha.length-1][stl]].maxRow = plocha.length-1;
                    vychody[plocha[plocha.length-1][stl]].minRow = plocha.length-1;
                    vychody[plocha[plocha.length-1][stl]].minCol = stl;
                    int pozicia = stl;
                    while (plocha[plocha.length-1][pozicia++] == plocha[plocha.length-1][stl] ) {
                        dlzka++;
                    }
                    vychody[plocha[plocha.length-1][stl]].maxCol = vychody[plocha[plocha.length-1][stl]].minCol + dlzka;
                    stl +=  dlzka;
                }

            }

            for (int riad = 0 ; riad < plocha.length; riad++){
                if (plocha[riad][0] != -1 ) {

                    int dlzka = -1;
                    if (vychody[plocha[riad][0]] == null) vychody[plocha[riad][0]] = new Vychody();
                    vychody[plocha[riad][0]].id = plocha[riad][0];
                    vychody[plocha[riad][0]].maxCol = 0;
                    vychody[plocha[riad][0]].minCol = 0;
                    vychody[plocha[riad][0]].minRow = riad;
                    int pozicia = riad;
                    while (plocha[pozicia++][0] == plocha[riad][0] ) {
                        dlzka++;
                    }
                    vychody[plocha[riad][0]].maxRow = vychody[plocha[riad][0]].minRow + dlzka;
                    riad +=  dlzka;
                }

            }

            for (int riad = 0 ; riad < plocha.length; riad++){
                if (plocha[riad][plocha[0].length-1] != -1 ) {

                    int dlzka = -1;
                    if (vychody[plocha[riad][plocha[0].length-1]] == null) vychody[plocha[riad][plocha[0].length-1]] = new Vychody();
                    vychody[plocha[riad][plocha[0].length-1]].id = plocha[riad][plocha[0].length-1];
                    vychody[plocha[riad][plocha[0].length-1]].maxCol = plocha[0].length-1;
                    vychody[plocha[riad][plocha[0].length-1]].minCol = plocha[0].length-1;
                    vychody[plocha[riad][plocha[0].length-1]].minRow = riad;
                    int pozicia = riad;
                    while (plocha[pozicia++][plocha[0].length-1] == plocha[riad][plocha[0].length-1] ) {
                        dlzka++;
                    }
                    vychody[plocha[riad][plocha[0].length-1]].maxRow = vychody[plocha[riad][plocha[0].length-1]].minRow + dlzka;
                    riad +=  dlzka;
                }

            }


        } catch ( Exception e) { }

    }

    void kresli() {
        if (plocha == null)
            return;

        GraphicsContext gc = canvas.getGraphicsContext2D();

        double w = canvas.getWidth();
        double h = canvas.getHeight();

        gc.setFill(Color.WHITE);
        gc.fillRect(0, 0, w, h);

        double okraj = Math.min(w, h) / 18.0;

        double vnutroW = w - 2 * okraj;
        double vnutroH = h - 2 * okraj;

        double bunkaW = vnutroW / (stlpce - 2);
        double bunkaH = vnutroH / (riadky - 2);

        for (int r = 0; r < riadky; r++) {
            for (int c = 0; c < stlpce; c++) {

                double x;
                double y;
                double bw;
                double bh;

                if (c == 0) {
                    x = 0;
                    bw = okraj;
                } else if (c == stlpce - 1) {
                    x = okraj + (stlpce - 2) * bunkaW;
                    bw = okraj;
                } else {
                    x = okraj + (c - 1) * bunkaW;
                    bw = bunkaW;
                }

                if (r == 0) {
                    y = 0;
                    bh = okraj;
                } else if (r == riadky - 1) {
                    y = okraj + (riadky - 2) * bunkaH;
                    bh = okraj;
                } else {
                    y = okraj + (r - 1) * bunkaH;
                    bh = bunkaH;
                }

                int hodnota = plocha[r][c];

                if (hodnota == -1) {
                    gc.setFill(Color.BLACK);
                } else if (hodnota == 0) {
                    gc.setFill(Color.WHITE);
                } else {
                    gc.setFill(farby[hodnota % farby.length]);
                }

                gc.fillRect(x, y, bw, bh);

                gc.setStroke(Color.GRAY);
                gc.strokeRect(x, y, bw, bh);
            }
        }
    }

    double okraj() {
        return Math.min(canvas.getWidth(), canvas.getHeight()) / 18.0;
    }

    double bunkaW() {
        return (canvas.getWidth() - 2 * okraj()) / (stlpce - 2);
    }

    double bunkaH() {
        return (canvas.getHeight() - 2 * okraj()) / (riadky - 2);
    }

    int getCol(double x) {
        double o = okraj();

        if (x < o)
            return 0;

        if (x >= o + (stlpce - 2) * bunkaW())
            return stlpce - 1;

        return 1 + (int)((x - o) / bunkaW());
    }

    int getRow(double y) {
        double o = okraj();

        if (y < o)
            return 0;

        if (y >= o + (riadky - 2) * bunkaH())
            return riadky - 1;

        return 1 + (int)((y - o) / bunkaH());
    }

    boolean mozeSaPohnut(Blok blok, int dr, int dc) {
        for (int i = 0; i < blok.riadky.size(); i++) {
            int r = blok.riadky.get(i);
            int c = blok.stlpce.get(i);

            int nr = r + dr;
            int nc = c + dc;

            if (nr < 0 || nc < 0 || nr >= riadky || nc >= stlpce)
                return false;

            if (plocha[nr][nc] == -1)
                return false;

            if (plocha[nr][nc] > 0 && plocha[nr][nc] != blok.id)
                return false;
        }

        return true;
    }

    void skusPohyb(Blok blok, int dr, int dc) {
        if (mozeVyjst(blok, dr, dc)) {
            odstranBlok(blok);
            pocetPresunov++;
            kresli();
            return;
        }

        if (!mozeSaPohnut(blok, dr, dc))
            return;
        if (!mozeSaPohnut(blok, dr, dc))
            return;

        for (int i = 0; i < blok.riadky.size(); i++) {
            int r = blok.riadky.get(i);
            int c = blok.stlpce.get(i);

            plocha[r][c] = 0;
        }

        for (int i = 0; i < blok.riadky.size(); i++) {
            blok.riadky.set(i, blok.riadky.get(i) + dr);
            blok.stlpce.set(i, blok.stlpce.get(i) + dc);
        }

        for (int i = 0; i < blok.riadky.size(); i++) {
            int r = blok.riadky.get(i);
            int c = blok.stlpce.get(i);

            plocha[r][c] = blok.id;
        }

        prepocitajHranice(blok);

        pocetPresunov++;

        kresli();
    }

    void prepocitajHranice(Blok blok) {
        blok.minRow = Integer.MAX_VALUE;
        blok.maxRow = Integer.MIN_VALUE;
        blok.minCol = Integer.MAX_VALUE;
        blok.maxCol = Integer.MIN_VALUE;

        for (int i = 0; i < blok.riadky.size(); i++) {
            int r = blok.riadky.get(i);
            int c = blok.stlpce.get(i);

            if (r < blok.minRow)
                blok.minRow = r;

            if (r > blok.maxRow)
                blok.maxRow = r;

            if (c < blok.minCol)
                blok.minCol = c;

            if (c > blok.maxCol)
                blok.maxCol = c;
        }
    }

    void odstranBlok(Blok blok) {
        for (int i = 0; i < blok.riadky.size(); i++) {
            int r = blok.riadky.get(i);
            int c = blok.stlpce.get(i);

            plocha[r][c] = 0;
        }

        bloky[blok.id] = null;

        if (vybranyBlok == blok)
            vybranyBlok = null;
    }

    boolean mozeVyjst(Blok blok, int dr, int dc) {
        if (blok == null)
            return false;

        Vychody v = vychody[blok.id];

        if (v == null)
            return false;

        if (dr == -1 && dc == 0) {
            if (v.minRow != 0 || v.maxRow != 0)
                return false;

            if (blok.minRow != 1)
                return false;

            return v.minCol <= blok.minCol && v.maxCol >= blok.maxCol;
        }

        if (dr == 1 && dc == 0) {
            if (v.minRow != riadky - 1 || v.maxRow != riadky - 1)
                return false;

            if (blok.maxRow != riadky - 2)
                return false;

            return v.minCol <= blok.minCol && v.maxCol >= blok.maxCol;
        }

        if (dr == 0 && dc == -1) {
            if (v.minCol != 0 || v.maxCol != 0)
                return false;

            if (blok.minCol != 1)
                return false;

            return v.minRow <= blok.minRow && v.maxRow >= blok.maxRow;
        }

        if (dr == 0 && dc == 1) {
            if (v.minCol != stlpce - 1 || v.maxCol != stlpce - 1)
                return false;

            if (blok.maxCol != stlpce - 2)
                return false;

            return v.minRow <= blok.minRow && v.maxRow >= blok.maxRow;
        }

        return false;
    }

    public static void main(String[] args) {
        launch(args);
        }
}

class Blok {

    int id;

    int minRow = Integer.MAX_VALUE;
    int maxRow = 0;
    int minCol = Integer.MAX_VALUE;
    int maxCol = 0;
    ArrayList<Integer> riadky = new ArrayList<>();
    ArrayList<Integer> stlpce = new ArrayList<>();
}

class Vychody {
    int id;

    int minRow = Integer.MAX_VALUE;
    int maxRow = 0;
    int minCol = Integer.MAX_VALUE;
    int maxCol = 0;
}
