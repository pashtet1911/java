package com.example.skuska;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.input.KeyCode;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.util.Duration;
import java.io.FileWriter;
import java.io.PrintWriter;
public class Hra extends Application {

    int[][] plocha;
    int riadky;
    int stlpce;

    Canvas canvas = new Canvas(800, 800);

    Blok vybranyBlok = null;

    Label info = new Label();

    int cas = 0;
    int pocetPresunov = 0;
    int level = 1;

    Timeline timer;

    Color[] farby = {
            Color.RED,
            Color.BLUE,
            Color.GREEN,
            Color.ORANGE,
            Color.CYAN,
            Color.MAGENTA,
            Color.YELLOW,
            Color.PINK,
            Color.BROWN,
            Color.GRAY,
            Color.LIGHTGREEN,
            Color.LIGHTBLUE
    };

    Vychody[] vychody = new Vychody[13];
    Blok[] bloky = new Blok[13];
    @Override
    public void start(Stage primaryStage) throws Exception {
        citajLevel("src/blocks1.txt");

        BorderPane root = new BorderPane();

        HBox panel = new HBox();
        panel.setSpacing(10);

        Button save = new Button("Save");
        Button load = new Button("Load");
        Button prev = new Button("Prev");
        Button next = new Button("Next");

        panel.getChildren().addAll(save, load, prev, next, info);

        Pane stred = new Pane(canvas);

        canvas.widthProperty().bind(stred.widthProperty());
        canvas.heightProperty().bind(stred.heightProperty());

        root.setCenter(stred);
        root.setBottom(panel);


        Scene scene = new Scene(root, 800, 800);

        save.setOnAction(e -> ulozHru());
        load.setOnAction(e -> nacitajHru());
        prev.setOnAction(e -> predchadzajuciLevel());
        next.setOnAction(e -> dalsiLevel());


        canvas.widthProperty().addListener(e -> kresli());
        canvas.heightProperty().addListener(e -> kresli());

        canvas.setOnMouseClicked(e -> {
            int r = getRow(e.getY());
            int c = getCol(e.getX());

            if (r < 0 || c < 0 || r >= riadky || c >= stlpce)
                return;

            int id = plocha[r][c];

            if (id > 0 && r > 0 && r < riadky - 1 && c > 0 && c < stlpce - 1) {
                vybranyBlok = bloky[id];
            } else {
                vybranyBlok = null;
            }

            kresli();
        });

        scene.setOnKeyPressed(e -> {
            if (vybranyBlok == null)
                return;

            if (e.getCode() == KeyCode.LEFT)
                skusPohyb(vybranyBlok, 0, -1);

            if (e.getCode() == KeyCode.RIGHT)
                skusPohyb(vybranyBlok, 0, 1);

            if (e.getCode() == KeyCode.UP)
                skusPohyb(vybranyBlok, -1, 0);

            if (e.getCode() == KeyCode.DOWN)
                skusPohyb(vybranyBlok, 1, 0);
        });

        primaryStage.setTitle("Blocks");
        primaryStage.setScene(scene);
        primaryStage.show();

        kresli();
    }

    void spustiTimer() {
        timer = new Timeline(new KeyFrame(Duration.seconds(1), e -> {
            cas++;
            aktualizujInfo();
        }));

        timer.setCycleCount(Timeline.INDEFINITE);
        timer.play();
    }

    void aktualizujInfo() {
        info.setText("Level: " + level + "   Cas: " + cas + "   Presuny: " + pocetPresunov);
    }

    void ulozHru() {
        try {
            PrintWriter pw = new PrintWriter(new FileWriter("save.txt"));

            pw.println(riadky + " " + stlpce);
            pw.println(level);
            pw.println(cas + " " + pocetPresunov);

            for (int r = 0; r < riadky; r++) {
                for (int c = 0; c < stlpce; c++) {
                    pw.print(plocha[r][c]);

                    if (c < stlpce - 1)
                        pw.print(" ");
                }

                pw.println();
            }

            pw.close();

            info.setText("Ulozene");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void nacitajHru() {
        try {
            BufferedReader br = new BufferedReader(new FileReader("save.txt"));

            String[] velkost = br.readLine().trim().split("\\s+");

            riadky = Integer.parseInt(velkost[0]);
            stlpce = Integer.parseInt(velkost[1]);

            level = Integer.parseInt(br.readLine().trim());

            String[] data = br.readLine().trim().split("\\s+");

            cas = Integer.parseInt(data[0]);
            pocetPresunov = Integer.parseInt(data[1]);

            plocha = new int[riadky][stlpce];

            for (int r = 0; r < riadky; r++) {
                String[] riadok = br.readLine().trim().split("\\s+");

                for (int c = 0; c < stlpce; c++) {
                    plocha[r][c] = Integer.parseInt(riadok[c]);
                }
            }

            br.close();

            obnovStruktury();

            kresli();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void obnovStruktury() {
        bloky = new Blok[13];
        vychody = new Vychody[13];

        for (int r = 0; r < riadky; r++) {
            for (int c = 0; c < stlpce; c++) {
                int cislo = plocha[r][c];

                if (cislo > 0 && r > 0 && r < riadky - 1 && c > 0 && c < stlpce - 1) {
                    if (bloky[cislo] == null) {
                        bloky[cislo] = new Blok();
                        bloky[cislo].id = cislo;
                    }

                    Blok b = bloky[cislo];

                    b.riadky.add(r);
                    b.stlpce.add(c);

                    if (r > b.maxRow) b.maxRow = r;
                    if (r < b.minRow) b.minRow = r;
                    if (c > b.maxCol) b.maxCol = c;
                    if (c < b.minCol) b.minCol = c;
                }
            }
        }

        nacitajVychodyZPlochy();
    }

    void predchadzajuciLevel() {
        if (level > 1)
            level--;

        cas = 0;
        pocetPresunov = 0;

        citajLevel("src/blocks" + level + ".txt");
        kresli();
    }

    void dalsiLevel() {
        if (level < 6)
            level++;

        cas = 0;
        pocetPresunov = 0;

        citajLevel("src/blocks" + level + ".txt");
        kresli();
    }

    void nacitajVychodyZPlochy() {
        for (int stl = 0 ; stl < plocha[0].length; stl++){
            if (plocha[0][stl] != -1 ) {

                int dlzka = -1;
                if (vychody[plocha[0][stl]] == null) vychody[plocha[0][stl]] = new Vychody();
                vychody[plocha[0][stl]].id = plocha[0][stl];
                vychody[plocha[0][stl]].maxRow = 0;
                vychody[plocha[0][stl]].minRow = 0;
                vychody[plocha[0][stl]].minCol = stl;
                int pozicia = stl;
                while (plocha[0][pozicia++] == plocha[0][stl] ) {
                    dlzka++;
                }
                vychody[plocha[0][stl]].maxCol = vychody[plocha[0][stl]].minCol + dlzka;
                stl +=  dlzka;
            }

        }

        for (int stl = 0 ; stl < plocha[0].length; stl++){
            if (plocha[plocha.length-1][stl] != -1 ) {

                int dlzka = -1;
                if (vychody[plocha[plocha.length-1][stl]] == null) vychody[plocha[plocha.length-1][stl]] = new Vychody();
                vychody[plocha[plocha.length-1][stl]].id = plocha[plocha.length-1][stl];
                vychody[plocha[plocha.length-1][stl]].maxRow = plocha.length-1;
                vychody[plocha[plocha.length-1][stl]].minRow = plocha.length-1;
                vychody[plocha[plocha.length-1][stl]].minCol = stl;
                int pozicia = stl;
                while (plocha[plocha.length-1][pozicia++] == plocha[plocha.length-1][stl] ) {
                    dlzka++;
                }
                vychody[plocha[plocha.length-1][stl]].maxCol = vychody[plocha[plocha.length-1][stl]].minCol + dlzka;
                stl +=  dlzka;
            }

        }

        for (int riad = 0 ; riad < plocha.length; riad++){
            if (plocha[riad][0] != -1 ) {

                int dlzka = -1;
                if (vychody[plocha[riad][0]] == null) vychody[plocha[riad][0]] = new Vychody();
                vychody[plocha[riad][0]].id = plocha[riad][0];
                vychody[plocha[riad][0]].maxCol = 0;
                vychody[plocha[riad][0]].minCol = 0;
                vychody[plocha[riad][0]].minRow = riad;
                int pozicia = riad;
                while (plocha[pozicia++][0] == plocha[riad][0] ) {
                    dlzka++;
                }
                vychody[plocha[riad][0]].maxRow = vychody[plocha[riad][0]].minRow + dlzka;
                riad +=  dlzka;
            }

        }

        for (int riad = 0 ; riad < plocha.length; riad++){
            if (plocha[riad][plocha[0].length-1] != -1 ) {

                int dlzka = -1;
                if (vychody[plocha[riad][plocha[0].length-1]] == null) vychody[plocha[riad][plocha[0].length-1]] = new Vychody();
                vychody[plocha[riad][plocha[0].length-1]].id = plocha[riad][plocha[0].length-1];
                vychody[plocha[riad][plocha[0].length-1]].maxCol = plocha[0].length-1;
                vychody[plocha[riad][plocha[0].length-1]].minCol = plocha[0].length-1;
                vychody[plocha[riad][plocha[0].length-1]].minRow = riad;
                int pozicia = riad;
                while (plocha[pozicia++][plocha[0].length-1] == plocha[riad][plocha[0].length-1] ) {
                    dlzka++;
                }
                vychody[plocha[riad][plocha[0].length-1]].maxRow = vychody[plocha[riad][plocha[0].length-1]].minRow + dlzka;
                riad +=  dlzka;
            }

        }
    }

    void citajLevel (String subor) {
        try {
            BufferedReader br = new BufferedReader(new FileReader(subor));

            ArrayList<String> lines = new ArrayList<>();

            String line;

            while ((line = br.readLine()) != null) {
                if (!line.trim().equals("")) {
                    lines.add(line);
                }
            }

            br.close();

            riadky = lines.size();

            String[] firstRow = lines.get(0).trim().split("\\s+");
            stlpce = firstRow.length;

            plocha = new int[riadky][stlpce];

            for (int r = 0; r < riadky; r++) {
                String[] riadok = lines.get(r).trim().split("\\s+");

                for (int c = 0; c < stlpce; c++) {
                    plocha[r][c] = Integer.parseInt(riadok[c]);
                    int cislo = Integer.parseInt(riadok[c]);
                    if (cislo > 0 && r > 0 && r < riadky - 1 && c > 0 && c < stlpce - 1) {

                        if (bloky[cislo] == null) {
                            bloky[cislo] = new Blok();
                        }
                        bloky[cislo].id = cislo;
                        bloky[cislo].riadky.add(r);
                        bloky[cislo].stlpce.add(c);

                        if (r >= bloky[cislo].maxRow ) bloky[cislo].maxRow = r;
                        if (r <= bloky[cislo].minRow ) bloky[cislo].minRow = r;
                        if (c >= bloky[cislo].maxCol ) bloky[cislo].maxCol = c;
                        if (c <= bloky[cislo].minCol ) bloky[cislo].minCol = c;
                    }
                }
            }

            int pocetObdlz = 0;
            for (Blok blok : bloky){

                if (blok != null) {
                    boolean jeObdl = true;
                    for (int r = blok.minRow; r <= blok.maxRow; r++){
                        for (int c = blok.minCol; c <= blok.maxCol; c++) {
                            if (plocha[r][c] != blok.id) {
                                jeObdl = false;
                            }
                        }
                    }
                    if (jeObdl){
                        pocetObdlz++;
                    }
                }


            }
            System.out.println(pocetObdlz);



            for (int stl = 0 ; stl < plocha[0].length; stl++){
                if (plocha[0][stl] != -1 ) {

                    int dlzka = -1;
                    if (vychody[plocha[0][stl]] == null) vychody[plocha[0][stl]] = new Vychody();
                    vychody[plocha[0][stl]].id = plocha[0][stl];
                    vychody[plocha[0][stl]].maxRow = 0;
                    vychody[plocha[0][stl]].minRow = 0;
                    vychody[plocha[0][stl]].minCol = stl;
                    int pozicia = stl;
                    while (plocha[0][pozicia++] == plocha[0][stl] ) {
                        dlzka++;
                    }
                    vychody[plocha[0][stl]].maxCol = vychody[plocha[0][stl]].minCol + dlzka;
                    stl +=  dlzka;
                }

            }

            for (int stl = 0 ; stl < plocha[0].length; stl++){
                if (plocha[plocha.length-1][stl] != -1 ) {

                    int dlzka = -1;
                    if (vychody[plocha[plocha.length-1][stl]] == null) vychody[plocha[plocha.length-1][stl]] = new Vychody();
                    vychody[plocha[plocha.length-1][stl]].id = plocha[plocha.length-1][stl];
                    vychody[plocha[plocha.length-1][stl]].maxRow = plocha.length-1;
                    vychody[plocha[plocha.length-1][stl]].minRow = plocha.length-1;
                    vychody[plocha[plocha.length-1][stl]].minCol = stl;
                    int pozicia = stl;
                    while (plocha[plocha.length-1][pozicia++] == plocha[plocha.length-1][stl] ) {
                        dlzka++;
                    }
                    vychody[plocha[plocha.length-1][stl]].maxCol = vychody[plocha[plocha.length-1][stl]].minCol + dlzka;
                    stl +=  dlzka;
                }

            }

            for (int riad = 0 ; riad < plocha.length; riad++){
                if (plocha[riad][0] != -1 ) {

                    int dlzka = -1;
                    if (vychody[plocha[riad][0]] == null) vychody[plocha[riad][0]] = new Vychody();
                    vychody[plocha[riad][0]].id = plocha[riad][0];
                    vychody[plocha[riad][0]].maxCol = 0;
                    vychody[plocha[riad][0]].minCol = 0;
                    vychody[plocha[riad][0]].minRow = riad;
                    int pozicia = riad;
                    while (plocha[pozicia++][0] == plocha[riad][0] ) {
                        dlzka++;
                    }
                    vychody[plocha[riad][0]].maxRow = vychody[plocha[riad][0]].minRow + dlzka;
                    riad +=  dlzka;
                }

            }

            for (int riad = 0 ; riad < plocha.length; riad++){
                if (plocha[riad][plocha[0].length-1] != -1 ) {

                    int dlzka = -1;
                    if (vychody[plocha[riad][plocha[0].length-1]] == null) vychody[plocha[riad][plocha[0].length-1]] = new Vychody();
                    vychody[plocha[riad][plocha[0].length-1]].id = plocha[riad][plocha[0].length-1];
                    vychody[plocha[riad][plocha[0].length-1]].maxCol = plocha[0].length-1;
                    vychody[plocha[riad][plocha[0].length-1]].minCol = plocha[0].length-1;
                    vychody[plocha[riad][plocha[0].length-1]].minRow = riad;
                    int pozicia = riad;
                    while (plocha[pozicia++][plocha[0].length-1] == plocha[riad][plocha[0].length-1] ) {
                        dlzka++;
                    }
                    vychody[plocha[riad][plocha[0].length-1]].maxRow = vychody[plocha[riad][plocha[0].length-1]].minRow + dlzka;
                    riad +=  dlzka;
                }

            }


        } catch ( Exception e) { }

    }

    void kresli() {
        if (plocha == null)
            return;

        GraphicsContext gc = canvas.getGraphicsContext2D();

        double w = canvas.getWidth();
        double h = canvas.getHeight();

        gc.setFill(Color.WHITE);
        gc.fillRect(0, 0, w, h);

        double bunkaW = w / stlpce;
        double bunkaH = h / riadky;

        for (int r = 0; r < riadky; r++) {
            for (int c = 0; c < stlpce; c++) {
                double x = c * bunkaW;
                double y = r * bunkaH;

                int hodnota = plocha[r][c];

                if (hodnota == -1)
                    gc.setFill(Color.BLACK);
                else if (hodnota == 0)
                    gc.setFill(Color.WHITE);
                else
                    gc.setFill(farby[hodnota % farby.length]);

                gc.fillRect(x, y, bunkaW, bunkaH);

                gc.setStroke(Color.GRAY);
                gc.strokeRect(x, y, bunkaW, bunkaH);
            }
        }
    }

    double bunkaW() {
        return canvas.getWidth() / stlpce;
    }

    double bunkaH() {
        return canvas.getHeight() / riadky;
    }

    int getCol(double x) {
        return (int)(x / bunkaW());
    }

    int getRow(double y) {
        return (int)(y / bunkaH());
    }

    boolean mozeSaPohnut(Blok blok, int dr, int dc) {
        for (int i = 0; i < blok.riadky.size(); i++) {
            int r = blok.riadky.get(i);
            int c = blok.stlpce.get(i);

            int nr = r + dr;
            int nc = c + dc;

            if (nr < 0 || nc < 0 || nr >= riadky || nc >= stlpce)
                return false;

            if (plocha[nr][nc] == -1)
                return false;

            if (plocha[nr][nc] > 0 && plocha[nr][nc] != blok.id)
                return false;
        }

        return true;
    }

    void skusPohyb(Blok blok, int dr, int dc) {
        if (mozeVyjst(blok, dr, dc)) {
            odstranBlok(blok);
            pocetPresunov++;
            kresli();
            return;
        }

        if (!mozeSaPohnut(blok, dr, dc))
            return;
        if (!mozeSaPohnut(blok, dr, dc))
            return;

        for (int i = 0; i < blok.riadky.size(); i++) {
            int r = blok.riadky.get(i);
            int c = blok.stlpce.get(i);

            plocha[r][c] = 0;
        }

        for (int i = 0; i < blok.riadky.size(); i++) {
            blok.riadky.set(i, blok.riadky.get(i) + dr);
            blok.stlpce.set(i, blok.stlpce.get(i) + dc);
        }

        for (int i = 0; i < blok.riadky.size(); i++) {
            int r = blok.riadky.get(i);
            int c = blok.stlpce.get(i);

            plocha[r][c] = blok.id;
        }

        prepocitajHranice(blok);

        pocetPresunov++;

        kresli();
    }

    void prepocitajHranice(Blok blok) {
        blok.minRow = Integer.MAX_VALUE;
        blok.maxRow = Integer.MIN_VALUE;
        blok.minCol = Integer.MAX_VALUE;
        blok.maxCol = Integer.MIN_VALUE;

        for (int i = 0; i < blok.riadky.size(); i++) {
            int r = blok.riadky.get(i);
            int c = blok.stlpce.get(i);

            if (r < blok.minRow)
                blok.minRow = r;

            if (r > blok.maxRow)
                blok.maxRow = r;

            if (c < blok.minCol)
                blok.minCol = c;

            if (c > blok.maxCol)
                blok.maxCol = c;
        }
    }

    void odstranBlok(Blok blok) {
        for (int i = 0; i < blok.riadky.size(); i++) {
            int r = blok.riadky.get(i);
            int c = blok.stlpce.get(i);

            plocha[r][c] = 0;
        }

        bloky[blok.id] = null;

        if (vybranyBlok == blok)
            vybranyBlok = null;
    }

    boolean mozeVyjst(Blok blok, int dr, int dc) {
        if (blok == null)
            return false;

        Vychody v = vychody[blok.id];

        if (v == null)
            return false;

        if (dr == -1 && dc == 0) {
            if (v.minRow != 0 || v.maxRow != 0)
                return false;

            if (blok.minRow != 1)
                return false;

            return v.minCol <= blok.minCol && v.maxCol >= blok.maxCol;
        }

        if (dr == 1 && dc == 0) {
            if (v.minRow != riadky - 1 || v.maxRow != riadky - 1)
                return false;

            if (blok.maxRow != riadky - 2)
                return false;

            return v.minCol <= blok.minCol && v.maxCol >= blok.maxCol;
        }

        if (dr == 0 && dc == -1) {
            if (v.minCol != 0 || v.maxCol != 0)
                return false;

            if (blok.minCol != 1)
                return false;

            return v.minRow <= blok.minRow && v.maxRow >= blok.maxRow;
        }

        if (dr == 0 && dc == 1) {
            if (v.minCol != stlpce - 1 || v.maxCol != stlpce - 1)
                return false;

            if (blok.maxCol != stlpce - 2)
                return false;

            return v.minRow <= blok.minRow && v.maxRow >= blok.maxRow;
        }

        return false;
    }

    public static void main(String[] args) {
        launch(args);
        }
}

class Blok {

    int id;

    int minRow = Integer.MAX_VALUE;
    int maxRow = 0;
    int minCol = Integer.MAX_VALUE;
    int maxCol = 0;
    ArrayList<Integer> riadky = new ArrayList<>();
    ArrayList<Integer> stlpce = new ArrayList<>();
}

class Vychody {
    int id;

    int minRow = Integer.MAX_VALUE;
    int maxRow = 0;
    int minCol = Integer.MAX_VALUE;
    int maxCol = 0;
}
