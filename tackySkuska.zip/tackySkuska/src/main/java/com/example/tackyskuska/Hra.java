package com.example.tackyskuska;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;

public class Hra extends Application {

    int[][] pole;
    int N = 0;
    int vyznamne;
    int indexCiele;
    int level = 1;
    Car[] auta = new Car[13];
    Color[] farby = {Color.WHITE, Color.BLUE, Color.RED, Color.ROSYBROWN, Color.DARKCYAN, Color.BROWN,
            Color.BLACK, Color.TURQUOISE, Color.GOLD, Color.GREEN, Color.LAVENDER, Color.YELLOW, Color.VIOLET};
    int vybraneAuto;
    int tahy = 0;
    int sekundy = 0;
    boolean vyhral = false;

    Canvas canvas;
    Label casLabel;
    Label tahyLabel;
    Label spravaLabel;
    Timeline timer;

    ArrayList<int[][]> historia = new ArrayList<>();
    ArrayList<Integer> historiaTahy = new ArrayList<>();
    ArrayList<Integer> historiaSekundy = new ArrayList<>();

    @Override
    public void start(Stage stage) {
        citajLevel("src/level1.txt");

        canvas = new Canvas(800, 700);
        canvas.setFocusTraversable(true);

        casLabel = new Label("Čas: 0");
        tahyLabel = new Label("Ťahy: 0");
        spravaLabel = new Label("");

        Button save = new Button("Save");
        Button load = new Button("Load");
        Button undo = new Button("Undo");
        Button prev = new Button("Prev");
        Button next = new Button("Next");

        HBox topPanel = new HBox(20, casLabel, tahyLabel, spravaLabel);
        HBox bottomPanel = new HBox(10, save, load, undo, prev, next);

        BorderPane root = new BorderPane();
        root.setTop(topPanel);
        root.setCenter(canvas);
        root.setBottom(bottomPanel);

        canvas.widthProperty().bind(root.widthProperty());
        canvas.heightProperty().bind(root.heightProperty().subtract(70));
        canvas.widthProperty().addListener(e -> kresli());
        canvas.heightProperty().addListener(e -> kresli());

        Scene scene = new Scene(root, 800, 800);

        canvas.setOnMouseClicked(e -> {
            canvas.requestFocus();

            int r = getRiadok(e.getY());
            int c = getStlpec(e.getX());

            if (r < 0 || r >= N || c < 0 || c >= N) return;
            if (pole[r][c] == 0) return;

            vybraneAuto = pole[r][c];
        });

        canvas.setOnKeyPressed(e -> {
            if (vyhral) return;
            if (vybraneAuto == 0) return;

            if (e.getCode().equals(KeyCode.LEFT)) {
                if ((auta[vybraneAuto].maxCol - auta[vybraneAuto].minCol) >= (auta[vybraneAuto].maxRow - auta[vybraneAuto].minRow)) {
                    if (skusPohyb(vybraneAuto, 0, -1)) kresli();
                }
            }

            if (e.getCode().equals(KeyCode.RIGHT)) {
                if ((auta[vybraneAuto].maxCol - auta[vybraneAuto].minCol) >= (auta[vybraneAuto].maxRow - auta[vybraneAuto].minRow)) {
                    if (skusPohyb(vybraneAuto, 0, 1)) kresli();
                }
            }

            if (e.getCode().equals(KeyCode.UP)) {
                if ((auta[vybraneAuto].maxCol - auta[vybraneAuto].minCol) <= (auta[vybraneAuto].maxRow - auta[vybraneAuto].minRow)) {
                    if (skusPohyb(vybraneAuto, -1, 0)) kresli();
                }
            }

            if (e.getCode().equals(KeyCode.DOWN)) {
                if ((auta[vybraneAuto].maxCol - auta[vybraneAuto].minCol) <= (auta[vybraneAuto].maxRow - auta[vybraneAuto].minRow)) {
                    if (skusPohyb(vybraneAuto, 1, 0)) kresli();
                }
            }
        });

        save.setOnAction(e -> {
            ulozHru();
            canvas.requestFocus();
        });

        load.setOnAction(e -> {
            nacitajHru();
            canvas.requestFocus();
        });

        undo.setOnAction(e -> {
            undo();
            canvas.requestFocus();
        });

        prev.setOnAction(e -> {
            if (level > 1) {
                level--;
                nacitajNovyLevel();
            }
            canvas.requestFocus();
        });

        next.setOnAction(e -> {
            if (level < 5) {
                level++;
                nacitajNovyLevel();
            }
            canvas.requestFocus();
        });

        stage.setTitle("Auta");
        stage.setScene(scene);
        stage.show();

        aktualizujInfo();
        spustiTimer();
        kresli();
        canvas.requestFocus();
    }

    void citajLevel(String subor) {
        auta = new Car[13];

        try {
            BufferedReader br = new BufferedReader(new FileReader(subor));

            N = Integer.parseInt(br.readLine().trim());
            pole = new int[N][N];
            String[] druhyR = br.readLine().trim().split(" ");
            vyznamne = Integer.parseInt(druhyR[0]);
            indexCiele = Integer.parseInt(druhyR[1]);

            String riadok = "";
            int i = 0;
            while ((riadok = br.readLine()) != null) {
                String[] r = riadok.trim().split(" ");
                for (int j = 0; j < N; j++) {
                    if (Integer.parseInt(r[j]) != 0) {
                        pole[i][j] = Integer.parseInt(r[j]);

                        if (auta[Integer.parseInt(r[j])] == null) {
                            auta[Integer.parseInt(r[j])] = new Car();
                        }
                        auta[Integer.parseInt(r[j])].x.add(j);
                        auta[Integer.parseInt(r[j])].y.add(i);

                        if (auta[Integer.parseInt(r[j])].minRow >= i) {
                            auta[Integer.parseInt(r[j])].minRow = i;
                        }

                        if (auta[Integer.parseInt(r[j])].maxRow <= i) {
                            auta[Integer.parseInt(r[j])].maxRow = i;
                        }

                        if (auta[Integer.parseInt(r[j])].minCol >= j) {
                            auta[Integer.parseInt(r[j])].minCol = j;
                        }

                        if (auta[Integer.parseInt(r[j])].maxCol <= j) {
                            auta[Integer.parseInt(r[j])].maxCol = j;
                        }
                    }
                }
                i++;
            }

            br.close();
        } catch (Exception e) {
            System.out.println("Chyba pri nacitani levelu");
        }
    }

    void kresli() {
        GraphicsContext gc = canvas.getGraphicsContext2D();

        gc.setFill(Color.WHITE);
        gc.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());

        double cell = Math.min(
                canvas.getWidth() / N,
                canvas.getHeight() / N
        );

        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                gc.setFill(farby[pole[i][j]]);
                gc.fillRect(j * cell, i * cell, cell, cell);

                if (pole[i][j] == vyznamne) {
                    gc.setFill(Color.BLACK);
                    gc.fillOval(
                            j * cell + cell * 0.25,
                            i * cell + cell * 0.25,
                            cell * 0.5,
                            cell * 0.5
                    );
                }
            }
        }

        if (auta[1] != null) {
            int cielovyRiadok = auta[vyznamne].minRow;

            gc.setStroke(Color.RED);
            gc.setLineWidth(3);

            gc.strokeOval(
                    (N - 1) * cell + cell * 0.2,
                    cielovyRiadok * cell + cell * 0.2,
                    cell * 0.6,
                    cell * 0.6
            );

            gc.strokeOval(
                    (N - 1) * cell + cell * 0.35,
                    cielovyRiadok * cell + cell * 0.35,
                    cell * 0.3,
                    cell * 0.3
            );
        }
    }

    boolean skusPohyb(int auto, int r, int c) {
        int pocet = auta[auto].x.size();

        for (int i = 0; i < pocet; i++) {
            int nr = auta[auto].y.get(i) + r;
            int nc = auta[auto].x.get(i) + c;

            if (nr < 0 || nr >= N || nc < 0 || nc >= N) {
                return false;
            }

            if (pole[nr][nc] != 0 && pole[nr][nc] != auto) {
                return false;
            }
        }

        ulozDoHistorie();

        for (int i = 0; i < pocet; i++) {
            pole[auta[auto].y.get(i)][auta[auto].x.get(i)] = 0;
        }

        for (int i = 0; i < pocet; i++) {
            auta[auto].y.set(i, auta[auto].y.get(i) + r);
            auta[auto].x.set(i, auta[auto].x.get(i) + c);
        }

        for (int i = 0; i < pocet; i++) {
            pole[auta[auto].y.get(i)][auta[auto].x.get(i)] = auto;
        }

        auta[auto].minRow += r;
        auta[auto].maxRow += r;
        auta[auto].minCol += c;
        auta[auto].maxCol += c;

        tahy++;
        aktualizujInfo();
        skontrolujVyhru();

        return true;
    }

    void spustiTimer() {
        if (timer != null) {
            timer.stop();
        }

        timer = new Timeline(new KeyFrame(Duration.seconds(1), e -> {
            sekundy++;
            aktualizujInfo();
        }));

        timer.setCycleCount(Timeline.INDEFINITE);
        timer.play();
    }

    void aktualizujInfo() {
        casLabel.setText("Čas: " + sekundy);
        tahyLabel.setText("Ťahy: " + tahy);
    }

    void ulozDoHistorie() {
        historia.add(kopirujPole(pole));
        historiaTahy.add(tahy);
        historiaSekundy.add(sekundy);
    }

    int[][] kopirujPole(int[][] p) {
        int[][] kopia = new int[N][N];

        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                kopia[i][j] = p[i][j];
            }
        }

        return kopia;
    }

    void undo() {
        if (historia.size() == 0) {
            return;
        }

        int posledny = historia.size() - 1;

        pole = historia.remove(posledny);
        tahy = historiaTahy.remove(posledny);
        sekundy = historiaSekundy.remove(posledny);
        vyhral = false;
        spravaLabel.setText("");

        obnovAuta();
        aktualizujInfo();
        kresli();
    }

    void obnovAuta() {
        auta = new Car[13];

        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                int cislo = pole[i][j];

                if (cislo != 0) {
                    if (auta[cislo] == null) {
                        auta[cislo] = new Car();
                    }

                    auta[cislo].x.add(j);
                    auta[cislo].y.add(i);

                    if (auta[cislo].minRow >= i) auta[cislo].minRow = i;
                    if (auta[cislo].maxRow <= i) auta[cislo].maxRow = i;
                    if (auta[cislo].minCol >= j) auta[cislo].minCol = j;
                    if (auta[cislo].maxCol <= j) auta[cislo].maxCol = j;
                }
            }
        }
    }

    void nacitajNovyLevel() {
        historia.clear();
        historiaTahy.clear();
        historiaSekundy.clear();

        tahy = 0;
        sekundy = 0;
        vybraneAuto = 0;
        vyhral = false;
        spravaLabel.setText("");

        citajLevel("src/level" + level + ".txt");
        aktualizujInfo();
        kresli();
    }

    void ulozHru() {
        try {
            FileWriter fw = new FileWriter("save.txt");

            fw.write(N + "\n");
            fw.write(vyznamne + " " + indexCiele + "\n");
            fw.write(sekundy + " " + tahy + " " + level + "\n");

            for (int i = 0; i < N; i++) {
                for (int j = 0; j < N; j++) {
                    fw.write(pole[i][j] + " ");
                }
                fw.write("\n");
            }

            fw.close();
            spravaLabel.setText("Uložené");
        } catch (Exception e) {
            spravaLabel.setText("Chyba Save");
        }
    }

    void nacitajHru() {
        try {
            BufferedReader br = new BufferedReader(new FileReader("save.txt"));

            N = Integer.parseInt(br.readLine().trim());

            String[] druhy = br.readLine().trim().split(" ");
            vyznamne = Integer.parseInt(druhy[0]);
            indexCiele = Integer.parseInt(druhy[1]);

            String[] treti = br.readLine().trim().split(" ");
            sekundy = Integer.parseInt(treti[0]);
            tahy = Integer.parseInt(treti[1]);
            level = Integer.parseInt(treti[2]);

            pole = new int[N][N];

            for (int i = 0; i < N; i++) {
                String[] r = br.readLine().trim().split(" ");
                for (int j = 0; j < N; j++) {
                    pole[i][j] = Integer.parseInt(r[j]);
                }
            }

            br.close();

            historia.clear();
            historiaTahy.clear();
            historiaSekundy.clear();
            vybraneAuto = 0;
            vyhral = false;
            spravaLabel.setText("Načítané");

            obnovAuta();
            aktualizujInfo();
            kresli();
        } catch (Exception e) {
            spravaLabel.setText("Chyba Load");
        }
    }

    void skontrolujVyhru() {
        if (vyhral) return;

        for (int i = 0; i < N; i++) {
            if (pole[i][indexCiele] == vyznamne) {
                vyhral = true;
                spravaLabel.setText("Gratulujem, vyhral si!");

                Timeline t = new Timeline(new KeyFrame(Duration.seconds(10), e -> {
                    if (level < 5) {
                        level++;
                        nacitajNovyLevel();
                    }
                }));

                t.play();
                return;
            }
        }
    }

    double velkostBunky() {
        return Math.min(canvas.getWidth() / N, canvas.getHeight() / N);
    }

    int getRiadok(double x) {
        return (int) (x / velkostBunky());
    }

    int getStlpec(double x) {
        return (int) (x / velkostBunky());
    }

    public static void main(String[] args) {
        launch(args);
    }
}

class Car {

    ArrayList<Integer> x = new ArrayList<>();
    ArrayList<Integer> y = new ArrayList<>();

    int minRow = Integer.MAX_VALUE;
    int maxRow = 0;
    int minCol = Integer.MAX_VALUE;
    int maxCol = 0;
}
