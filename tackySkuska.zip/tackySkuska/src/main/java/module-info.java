module com.example.tackyskuska {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.tackyskuska to javafx.fxml;
    exports com.example.tackyskuska;
}